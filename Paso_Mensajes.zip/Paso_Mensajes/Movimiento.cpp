//
// Created by Janus on 26/10/2025.
//
#include "Tablero.h"
#include "Movimiento.h"
#include <string>
/*
===============================================================================
                        IMPLEMENTACIÓN DE LA CLASE MOVIMIENTO
===============================================================================
La clase Movimiento repsresenta las acciones que puede realizar el avatar ,
modificando sus coordenadas para simular su desplazamiento

Se demuestra:
 - Paso de objetos por referencia.
 -Asociar una posicion existente del tablero (por referencia)
 - Cambiar la posicion actual moviendose en distintas dirreciones
===============================================================================
*/

Movimiento::Movimiento(  int& x,  int& y) : PosicionX(x), PosicionY(y) {} // Aqui nos salia un error si usabamos this en vez de definirlo asi Atributo(Parametro) y no hay necesidad de poner &en estos atributos pero si en los de .h

void Movimiento::MoverseArriba() {
    PosicionY--;
};
void Movimiento::MoverseAbajo() {
    PosicionY++;
}
void Movimiento::MoverseDerecha() {
    PosicionX++;
}
void Movimiento::MoverseIzquierda() {
    PosicionX--;
}
std::string Movimiento::Detectar() {
    Tablero tablero;  // creamos un objeto temporal para acceder a la matriz
    int (&matriz)[10][10] = tablero.GetMatriz();

    bool der = DetectarVacioDerecha();
    bool izq = DetectarVacioIzquierda();
    bool arr = DetectarVacioArriba();
    bool abj = DetectarVacioAbajo();

    std::string resultado = "Detectado: ";
    resultado += der ? "Derecha " : "";
    resultado += izq ? "Izquierda " : "";
    resultado += arr ? "Arriba " : "";
    resultado += abj ? "Abajo " : "";

    if (resultado == "Detectado: ") resultado += "ningún vacío.";
    return resultado;
}

// ====== Funciones de detección individuales ======

bool Movimiento::DetectarVacioDerecha() {
    Tablero tablero;
    int (&matriz)[10][10] = tablero.GetMatriz();
    if (PosicionX < 9)
        return matriz[PosicionY][PosicionX + 1] == 0;
    return false;
}

bool Movimiento::DetectarVacioIzquierda() {
    Tablero tablero;
    int (&matriz)[10][10] = tablero.GetMatriz();
    if (PosicionX > 0)
        return matriz[PosicionY][PosicionX - 1] == 0;
    return false;
}

bool Movimiento::DetectarVacioArriba() {
    Tablero tablero;
    int (&matriz)[10][10] = tablero.GetMatriz();
    if (PosicionY > 0)
        return matriz[PosicionY - 1][PosicionX] == 0;
    return false;
}

bool Movimiento::DetectarVacioAbajo() {
    Tablero tablero;
    int (&matriz)[10][10] = tablero.GetMatriz();
    if (PosicionY < 9)
        return matriz[PosicionY + 1][PosicionX] == 0;
    return false;
}



